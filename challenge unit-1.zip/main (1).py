year = 2023
if(year%4 == 0):
  print("leap Year")
else:
  print("not Leap Year")